#include <linux/fs.h>
#include <linux//module.h>
#include <linux/cdev.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/init.h>

#define DEVICE_NAME "heapwn"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("rui");
MODULE_DESCRIPTION("Balapan Heap Pwn (Kernel Version)) - ACE CTF 2024");

typedef struct {
	size_t size;
	char *data;
} req_t;

char *heap = NULL;

static long device_ioctl(struct file *filp, unsigned int cmd, unsigned long arg) {

    req_t req;
    if (copy_from_user(&req, (req_t*)arg, sizeof(req_t))) return -EINVAL;

    switch (cmd) {
        case 0xACE1: {
		heap = kmalloc(req.size, GFP_KERNEL);
   		if (copy_from_user(heap, req.data, req.size)) return -EFAULT;		
		break;
	}
        
        case 0xACE2: {
        	if (heap && copy_to_user(req.data, heap, req.size)) return -EFAULT;
		break;
	}
        
        case 0xACE3: {
		kfree(heap);
		break;
	}
	default: return -EINVAL;
    }
    return 0;
}

static struct file_operations fops = {
    .unlocked_ioctl = device_ioctl,
    .owner = THIS_MODULE,
};

static dev_t dev;
static struct cdev c_dev;

static int __init initial(void) {
  if (alloc_chrdev_region(&dev, 0, 1, DEVICE_NAME)) {
    printk(KERN_WARNING "Failed to register device\n");
    return -EBUSY;
  }

  cdev_init(&c_dev, &fops);
  c_dev.owner = THIS_MODULE;

  if (cdev_add(&c_dev, dev, 1)) {
    printk(KERN_WARNING "Failed to add cdev\n");
    unregister_chrdev_region(dev, 1);
    return -EBUSY;
  }
  return 0;
}

static void __exit cleanup(void) {
    cdev_del(&c_dev);
    unregister_chrdev_region(dev, 1);
}

module_init(initial);
module_exit(cleanup);
